// sorter.h

#ifndef _NETWORK_H_
#define _NETWORK_H_

pthread_t idNetwork;
// Begin/end the background thread which sorts random permutations.
void Network_Listening(void);

#endif
